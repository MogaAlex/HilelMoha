class Human:

    def __init__(self, gender, age, first_name, last_name):
        self.gender = gender
        self.age = age
        self.first_name = first_name
        self.last_name = last_name


    def __str__(self):
        return f'{self.gender} {self.age} {self.first_name} {self.last_name}'


class Student(Human):

    def __init__(self, gender, age, first_name, last_name, record_book):
        self.gender = gender
        self.age = age
        self.first_name = first_name
        self.last_name = last_name
        self.record_book = record_book

    def __str__(self):
        return f'{self.gender} {self.age} {self.first_name} {self.last_name} {self.record_book}'


class Group:

    def __init__(self, number):
        self.number = number
        self.group = set()

    def add_student(self, student):
        self.group.add(student)


    def delete_student(self, last_name):
        for student in list(self.group):
            if last_name in student.last_name:
                self.group.remove(student)
            else:
                None

    def find_student(self, last_name):
        for student in self.group:
            if last_name in student.last_name:
                return student
            else:
                None


    def __str__(self):
        all_students = ''
        for student in self.group:
            all_students += f'{student.first_name} {student.last_name} {student.age} {student.gender} {student.record_book}\n'
        return f'Number:{self.number}\n{all_students} '